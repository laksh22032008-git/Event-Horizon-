// Benchmark from the TRACK brief, plus one changed input (M87*).
// Run: npm test
const test = require('node:test');
const assert = require('node:assert');
const { derived, trace } = require('../public/js/physics.js');

const within = (x, ref, tol = 0.25) => Math.abs(x - ref) / ref <= tol;

test('Sgr A* derived scales (M = 4.3e6 Msun, D = 8.28 kpc)', () => {
  const D = derived(4.3e6, 8.28);
  console.log(`  Rs=${D.Rs.toExponential(3)} m  rph=${D.rph.toExponential(3)} m  bc=${D.bc.toExponential(3)} m  isco=${D.isco.toExponential(3)} m  shadow=${D.shadow.toFixed(2)} uas`);
  assert.ok(within(D.Rs, 1.27e10));
  assert.ok(within(D.rph, 1.9e10));
  assert.ok(within(D.bc, 3.3e10));
  assert.ok(within(D.isco, 3.8e10));
  assert.ok(within(D.shadow, 51.8), 'shadow within 25% of EHT 51.8 uas');
});

test('Beam A, b = 2.0 Rs, is captured', () => {
  const t = trace(2.0 * 2); // b in units of M (1 Rs = 2 M)
  console.log(`  A: ${t.status}`);
  assert.strictEqual(t.status, 'captured');
});

test('Beam B, b = 2.6 Rs, skims the photon sphere', () => {
  const t = trace(2.6 * 2);
  console.log(`  B: ${t.status}, ${t.turns.toFixed(2)} turns, r_min = ${(t.rmin / 2).toFixed(4)} Rs`);
  assert.ok(within(t.rmin / 2, 1.5), 'closest approach near 1.5 Rs');
  assert.ok(t.turns > 1, 'whirls at least one full turn');
});

test('Beam C, b = 10 Rs, escapes deflected ~13-14 deg', () => {
  const t = trace(10 * 2);
  console.log(`  C: ${t.status}, alpha = ${t.deflDeg.toFixed(3)} deg (weak-field 11.46)`);
  assert.strictEqual(t.status, 'escaped');
  assert.ok(t.deflDeg > 13 && t.deflDeg < 14);
});

test('Critical impact parameter separates capture from escape', () => {
  const bc = 3 * Math.sqrt(3); // in M
  assert.strictEqual(trace(bc - 0.01).status, 'captured');
  assert.notStrictEqual(trace(bc + 0.01).status, 'captured');
});

test('Changed input: M87* (6.5e9 Msun, 16.8 Mpc) vs EHT 42 uas', () => {
  const D = derived(6.5e9, 16800);
  console.log(`  M87* shadow = ${D.shadow.toFixed(2)} uas`);
  assert.ok(within(D.shadow, 42));
});
