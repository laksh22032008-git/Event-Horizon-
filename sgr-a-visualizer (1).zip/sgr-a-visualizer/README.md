# SGR A* — Black Hole Visualizer

A hackathon entry for **ENDURANCE · Track: Black Hole Visualizer** (Equinox – The Space Club).

It shows exact light paths around Sagittarius A* by integrating the Schwarzschild photon orbit
equation `d²u/dφ² + u = 3Mu²` with 4th-order Runge–Kutta. The page shows benchmark beams A/B/C,
the 53 μas shadow next to EHT's 51.8 μas ring, and a GPU ray-traced hero inspired by *Interstellar*.

## Run locally

```bash
node server.js          # or: npm start
# open http://localhost:8080
```

No install step is needed. The site uses only Node's standard library. Node 18 or newer is required.
Set `PORT` / `HOST` to change the bind address. A health check is served at `/healthz`.

## Verify the physics

```bash
npm test
```

This runs the brief's benchmark (Rs, photon sphere, b_c, ISCO, beams A/B/C, shadow) and a changed input
(M87*) against the same `public/js/physics.js` the website uses.

## Deploy

| Target | How |
|---|---|
| **Netlify** | Drag the `public/` folder onto app.netlify.com/drop, or connect the repo (`netlify.toml` included) |
| **Vercel** | `npx vercel` in this folder (`vercel.json` points to `public/`) |
| **GitHub Pages** | Push, then Settings → Pages → deploy from the `/public` folder (via Actions) or copy `public/` to `docs/` |
| **Render** | New → Blueprint, select repo (`render.yaml` included) |
| **Docker / any VPS** | `docker build -t sgr-a . && docker run -p 8080:8080 sgr-a` |
| **Any static host** | Upload the contents of `public/` (index.html, css/, js/, favicon.svg, 404.html) |

## Structure

```
public/
  index.html        page markup
  css/style.css     styles
  js/physics.js     constants, derived scales, RK4 trace (also used by tests)
  js/hero.js        WebGL geodesic ray tracer (visual only)
  js/app.js         2-D simulator, sky view, test tables, UI
  404.html, favicon.svg
server.js           zero-dependency static server (gzip, security headers, /healthz)
test/               node:test benchmark
```

## Values & sources

- Mass 4.30 × 10⁶ M☉, distance 8.28 kpc — GRAVITY Collaboration 2022, A&A 657 L12
- Ring diameter 51.8 ± 2.3 μas — EHT Collaboration 2022, ApJL 930 L12
- Rendering reference — James, von Tunzelmann, Franklin & Thorne 2015, CQG 32 065001

Simplification: non-spinning (Schwarzschild) hole. Spin changes the shadow by only a few per cent.
