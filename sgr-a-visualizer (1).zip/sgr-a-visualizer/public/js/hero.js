/* GPU geodesic ray tracer for the hero (units: Rs = 1). Visual only. */
/* =========================================================
   HERO — GPU geodesic ray tracer (units: Rs = 1)
   ========================================================= */
(function hero(){
  const cv=$('bh'); const gl=cv.getContext('webgl',{antialias:false,preserveDrawingBuffer:false});
  if(!gl){ $('fallback').hidden=false; cv.style.display='none'; return; }
  const vs=`attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}`;
  const fs=`precision highp float;
uniform vec2 R;uniform float T;uniform vec2 Mo;
float hash(vec3 p){p=fract(p*0.3183099+.1);p*=17.0;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}
float noise(vec3 x){vec3 i=floor(x);vec3 f=fract(x);f=f*f*(3.-2.*f);
 return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),
            mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);}
float fbm(vec3 p){float a=.5,s=0.;for(int i=0;i<5;i++){s+=a*noise(p);p=p*2.03+vec3(1.7,9.2,3.1);a*=.5;}return s;}
vec3 sky(vec3 d){
 vec3 c=vec3(0.);
 float n=fbm(d*2.2+vec3(3.,1.,7.));
 float band=exp(-pow(d.y*2.6+0.35*d.x,2.)*2.);
 c+=vec3(.10,.085,.075)*pow(n,2.6)*band*1.6;
 c+=vec3(.025,.035,.05)*pow(n,3.)*.8;
 for(int k=0;k<3;k++){float sc=k==0?90.:(k==1?180.:340.);
   vec3 q=d*sc;vec3 id=floor(q);vec3 f=fract(q)-.5;float h=hash(id+float(k)*13.1);
   float th=k==0?.992:(k==1?.985:.975);
   if(h>th){float r=length(f);float b=(h-th)/(1.-th);
     vec3 tint=mix(vec3(1.,.82,.65),vec3(.75,.85,1.),hash(id*1.7));
     c+=tint*smoothstep(.22,0.,r)*b*(k==0?3.5:1.6);}}
 return c;}
vec3 disk(vec3 p,vec3 dir,out float al){
 float r=length(p.xz);
 float inner=smoothstep(2.75,3.25,r), outer=smoothstep(12.,6.5,r);
 if(inner*outer<=0.){al=0.;return vec3(0.);}
 float ang=atan(p.z,p.x)+T*1.1*pow(r,-1.5);
 float n=fbm(vec3(cos(ang)*2.2,sin(ang)*2.2,r*2.6));
 float n2=fbm(vec3(cos(ang)*6.,sin(ang)*6.,r*7.));
 float I=inner*outer*pow(3.2/r,1.5)*(.35+.95*n)*(.75+.5*n2);
 vec3 vd=normalize(vec3(-p.z,0.,p.x));float v=sqrt(.5/r);
 float g=sqrt(1.-v*v)/(1.-v*dot(vd,-dir))*sqrt(1.-1./r);
 I*=mix(1.,pow(g,3.),.7);
 float t=clamp(I*g,0.,2.);
 vec3 deep=vec3(.45,.09,.02),warm=vec3(1.,.5,.16),hot=vec3(1.,.93,.80);
 vec3 c=mix(deep,warm,smoothstep(0.,.45,t));c=mix(c,hot,smoothstep(.45,1.25,t));
 al=clamp(I*1.15,0.,.97);
 return c*I*2.4;}
void main(){
 vec2 uv=(gl_FragCoord.xy-.5*R)/R.y;
 float yaw=T*.035+Mo.x*3.;float pitch=clamp(.085+Mo.y*1.2,-1.3,1.3);
 float dist=16.;
 vec3 ro=dist*vec3(cos(pitch)*sin(yaw),sin(pitch),cos(pitch)*cos(yaw));
 vec3 fw=normalize(-ro);vec3 rt=normalize(cross(fw,vec3(0.,1.,0.)));vec3 up=cross(rt,fw);
 float roll=-.06;vec3 rt2=rt*cos(roll)+up*sin(roll);vec3 up2=up*cos(roll)-rt*sin(roll);
 vec3 v=normalize(fw*1.55+uv.x*rt2+uv.y*up2);
 vec3 p=ro;vec3 hv=cross(p,v);float h2=dot(hv,hv);
 vec3 col=vec3(0.);float tr=1.;bool hit=false;
 for(int i=0;i<320;i++){
   float r=length(p);
   float dt=clamp(.06*r,.012,1.2);
   vec3 a=-1.5*h2*p/pow(r,5.);
   vec3 v2=v+a*dt;vec3 p2=p+v2*dt;
   if(p.y*p2.y<0.){float t=p.y/(p.y-p2.y);vec3 c=mix(p,p2,t);float al;vec3 dc=disk(c,normalize(v2),al);col+=tr*dc*al;tr*=1.-al;}
   p=p2;v=v2;
   if(dot(p,p)<1.){hit=true;break;}
   if(r>45.&&dot(p,v)>0.)break;
   if(tr<.02)break;
 }
 if(!hit)col+=tr*sky(normalize(v));
 col=vec3(1.)-exp(-col*1.5);
 col=pow(col,vec3(.92));
 col*=vec3(1.02,1.,.97);
 col*=1.-.45*dot(uv,uv);
 col+=(hash(vec3(gl_FragCoord.xy,floor(T*24.)))-.5)*.035;
 gl_FragColor=vec4(col,1.);}`;
  function sh(t,s){const o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);if(!gl.getShaderParameter(o,gl.COMPILE_STATUS)){console.warn(gl.getShaderInfoLog(o));return null;}return o;}
  const v=sh(gl.VERTEX_SHADER,vs), f=sh(gl.FRAGMENT_SHADER,fs);
  if(!v||!f){ $('fallback').hidden=false; cv.style.display='none'; return; }
  const pr=gl.createProgram();gl.attachShader(pr,v);gl.attachShader(pr,f);gl.linkProgram(pr);gl.useProgram(pr);
  const buf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),gl.STATIC_DRAW);
  const loc=gl.getAttribLocation(pr,'p');gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,2,gl.FLOAT,false,0,0);
  const uR=gl.getUniformLocation(pr,'R'),uT=gl.getUniformLocation(pr,'T'),uM=gl.getUniformLocation(pr,'Mo');
  let scale=Math.min(0.6, 1100/innerWidth); let mo=[0,0], tgt=[0,0], drag=null;
  function size(){cv.width=Math.max(320,Math.floor(cv.clientWidth*scale));cv.height=Math.max(180,Math.floor(cv.clientHeight*scale));gl.viewport(0,0,cv.width,cv.height);}
  size(); addEventListener('resize',size);
  cv.addEventListener('pointerdown',e=>{drag=[e.clientX,e.clientY,tgt[0],tgt[1]];cv.setPointerCapture(e.pointerId);});
  cv.addEventListener('pointermove',e=>{if(!drag)return;tgt[0]=drag[2]+(e.clientX-drag[0])/innerWidth;tgt[1]=Math.max(-.9,Math.min(.9,drag[3]+(e.clientY-drag[1])/innerHeight));});
  addEventListener('pointerup',()=>drag=null);
  let t0=performance.now(), last=t0, frames=0, acc=0, visible=true;
  new IntersectionObserver(es=>visible=es[0].isIntersecting).observe(cv);
  function loop(now){
    requestAnimationFrame(loop);
    if(!visible){last=now;return;}
    const dt=now-last; last=now; frames++; acc+=dt;
    if(acc>1000){const fps=frames*1000/acc; $('h-fps').textContent=fps.toFixed(0)+' fps';
      if(fps<28&&scale>0.28){scale*=0.85;size();} else if(fps>55&&scale<0.75){scale*=1.08;size();}
      frames=0;acc=0;}
    mo[0]+=(tgt[0]-mo[0])*.06; mo[1]+=(tgt[1]-mo[1])*.06;
    const T=(now-t0)/1000;
    gl.uniform2f(uR,cv.width,cv.height); gl.uniform1f(uT,T); gl.uniform2f(uM,mo[0],mo[1]);
    gl.drawArrays(gl.TRIANGLES,0,3);
    const yaw=((T*.035+mo[0]*3)*180/Math.PI)%360, pitch=Math.max(-1.3,Math.min(1.3,.085+mo[1]*1.2))*180/Math.PI;
    $('h-yaw').textContent=yaw.toFixed(1)+'°'; $('h-pitch').textContent=pitch.toFixed(1)+'°';
  }
  requestAnimationFrame(loop);
})();

/* letterbox bars retract on scroll */
addEventListener('scroll',()=>{const k=Math.min(1,scrollY/(innerHeight*.6));const h=(11*(1-k))+'vh';$('barT').style.height=h;$('barB').style.height=h;},{passive:true});

