/* 2-D simulator, sky view, tests, UI. Depends on physics.js. */
/* =========================================================
   2-D SIMULATOR
   ========================================================= */
const sim={cv:$('sim'), beams:[], fan:[], showFan:false, showDisc:true, zoom:0, t0:performance.now()};
const ZOOMS=[13,6,30]; // half-height in Rs
const BEAMS=[{key:'A',bRs:2.0,col:'#ff5a4e'},{key:'B',bRs:2.6,col:'#ffc35a'},{key:'C',bRs:10,col:'#5ad1ff'}];

function buildPaths(){
  sim.beams=BEAMS.map(B=>({...B, tr:trace(B.bRs*2)}));
  sim.custom={key:'U',bRs:state.bRs,col:'#ffffff',tr:trace(state.bRs*2)};
  [...sim.beams,sim.custom].forEach(b=>{const L=[0];const p=b.tr.pts;for(let i=1;i<p.length;i++)L.push(L[i-1]+Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]));b.len=L;});
}
function buildFan(){
  sim.fan=[]; for(let i=0;i<46;i++){const bRs=0.4+i*0.21; const t=trace(bRs*2,{h:0.004}); sim.fan.push(t);}
}
/* disc texture */
const discTex=(function(){const N=640,c=document.createElement('canvas');c.width=c.height=N;const x=c.getContext('2d');const im=x.createImageData(N,N);
  const rnd=(a,b)=>{const s=Math.sin(a*127.1+b*311.7)*43758.5453;return s-Math.floor(s);};
  for(let j=0;j<N;j++)for(let i=0;i<N;i++){const X=(i-N/2)/(N/2)*14, Y=(j-N/2)/(N/2)*14; const r=Math.hypot(X,Y); // r in Rs, outer 14
    let I=0; if(r>2.8&&r<14){const a=Math.atan2(Y,X); const streak=0.55+0.45*Math.sin(r*9+3*Math.sin(a*2+r))*Math.sin(r*3.3+a)+0.25*rnd(Math.round(r*14),Math.round(a*40));
      I=Math.min(1,Math.max(0,(r-2.8)/0.6))*Math.max(0,1-(r-3)/11)**1.4*streak*Math.pow(3.2/r,0.9);}
    const k=(j*N+i)*4; im.data[k]=255*Math.min(1,I*1.4); im.data[k+1]=255*Math.min(1,I*I*1.0+I*0.35); im.data[k+2]=255*Math.min(1,I*I*0.55); im.data[k+3]=255*Math.min(1,I*1.3);}
  x.putImageData(im,0,0); return c;})();
const starTex=(function(){const c=document.createElement('canvas');c.width=1600;c.height=900;const x=c.getContext('2d');x.fillStyle='#000';x.fillRect(0,0,1600,900);
  for(let i=0;i<900;i++){const a=Math.random();x.fillStyle=`rgba(${200+55*Math.random()|0},${200+40*Math.random()|0},255,${a*a*.7})`;const s=Math.random()<.04?1.6:0.8;x.fillRect(Math.random()*1600,Math.random()*900,s,s);}return c;})();

function simSize(){const r=sim.cv.getBoundingClientRect();const d=Math.min(2,devicePixelRatio||1);sim.cv.width=r.width*d;sim.cv.height=r.height*d;sim.dpr=d;}
function drawSim(now){
  const cv=sim.cv, x=cv.getContext('2d'), W=cv.width, H=cv.height, d=sim.dpr;
  const halfRs=ZOOMS[sim.zoom]; const sc=H/2/(halfRs*2); // px per M
  const cx=W*0.58, cy=H/2; const P=(p)=>[cx+p[0]*sc, cy-p[1]*sc];
  x.setTransform(1,0,0,1,0,0); x.globalCompositeOperation='source-over';
  x.drawImage(starTex,0,0,W,H);
  // grid in Rs
  x.strokeStyle='rgba(255,255,255,0.045)'; x.lineWidth=1;
  const step=halfRs>20?5:(halfRs>8?2:1);
  for(let k=-60;k<=60;k+=step){const gx=cx+k*2*sc, gy=cy-k*2*sc; if(gx>0&&gx<W){x.beginPath();x.moveTo(gx,0);x.lineTo(gx,H);x.stroke();} if(gy>0&&gy<H){x.beginPath();x.moveTo(0,gy);x.lineTo(W,gy);x.stroke();}}
  x.fillStyle='rgba(141,137,127,.7)'; x.font=`${10*d}px IBM Plex Mono`;
  for(let k=-60;k<=60;k+=step){const gy=cy-k*2*sc; if(k!==0&&gy>20*d&&gy<H-10*d) x.fillText(k+' Rs',W-46*d,gy-4*d);}
  const T=(now-sim.t0)/1000;
  // disc
  if(sim.showDisc){x.save();x.translate(cx,cy);x.rotate(-T*0.12);x.globalCompositeOperation='lighter';x.globalAlpha=.55;const R=14*2*sc;x.drawImage(discTex,-R,-R,2*R,2*R);x.restore();x.globalAlpha=1;x.globalCompositeOperation='source-over';}
  // b_c lines
  const bc=3*Math.sqrt(3);
  x.setLineDash([6*d,6*d]); x.strokeStyle='rgba(143,195,223,.45)'; x.lineWidth=1*d;
  [bc,-bc].forEach(y=>{const a=P([-500,y]),b=P([0,y]);x.beginPath();x.moveTo(a[0],a[1]);x.lineTo(b[0],b[1]);x.stroke();});
  x.fillStyle='rgba(143,195,223,.8)'; x.fillText('b_c = 2.598 Rs',P([0,bc])[0]-120*d,P([0,bc])[1]-6*d);
  // photon sphere & ISCO
  x.beginPath();x.arc(cx,cy,3*sc,0,7);x.stroke();
  x.setLineDash([1.5*d,5*d]); x.strokeStyle='rgba(240,166,90,.55)'; x.beginPath();x.arc(cx,cy,6*sc,0,7);x.stroke();
  x.setLineDash([]);
  x.fillStyle='rgba(143,195,223,.85)'; x.fillText('photon sphere 1.5 Rs',cx+3*sc*0.72+6*d,cy+3*sc*0.72+12*d);
  x.fillStyle='rgba(240,166,90,.85)'; x.fillText('ISCO 3 Rs',cx+6*sc*0.71+6*d,cy-6*sc*0.71-6*d);
  // fan
  if(sim.showFan){x.lineWidth=1*d;sim.fan.forEach((t,i)=>{x.strokeStyle=t.status==='captured'?'rgba(255,90,78,.22)':'rgba(220,230,255,.18)';[1,-1].forEach(sg=>{x.beginPath();t.pts.forEach((p,j)=>{const q=P([p[0],sg*p[1]]);j?x.lineTo(q[0],q[1]):x.moveTo(q[0],q[1]);});x.stroke();});});}
  // beams — start where they enter the view, constant speed (light speed is the same for all)
  const halfWM=(W-cx)/sc*1.02+0, leftM=cx/sc*1.02;
  const speed=halfRs*1.25;
  const all=[...sim.beams,sim.custom];
  const enter=b=>{const p=b.tr.pts;for(let i=1;i<p.length;i++){if(p[i][0]>-leftM){const f=(-leftM-p[i-1][0])/(p[i][0]-p[i-1][0]);return b.len[i-1]+Math.max(0,Math.min(1,f))*(b.len[i]-b.len[i-1]);}}return 0;};
  const span=Math.min(Math.max(...all.map(b=>b.len[b.len.length-1]-enter(b))), halfRs*2*7);
  const cycle=span/speed+2.2;
  const t=((now-sim.t0)/1000)%cycle;
  let dist=0;
  all.forEach(b=>{
    const p=b.tr.pts, L=b.len; if(p.length<2)return;
    dist=enter(b)+t*speed;
    let n=1; while(n<L.length&&L[n]<dist)n++;
    x.save(); x.strokeStyle=b.col; x.lineWidth=(b.key==='U'?1.6:2.2)*d; x.shadowColor=b.col; x.shadowBlur=14*d; x.globalAlpha=b.key==='U'?.85:1;
    x.beginPath(); for(let i=0;i<Math.min(n,p.length);i++){const q=P(p[i]);i?x.lineTo(q[0],q[1]):x.moveTo(q[0],q[1]);}
    let head=null;
    if(n<p.length){const f=(dist-L[n-1])/(L[n]-L[n-1]);head=[p[n-1][0]+(p[n][0]-p[n-1][0])*f,p[n-1][1]+(p[n][1]-p[n-1][1])*f];const q=P(head);x.lineTo(q[0],q[1]);}
    x.stroke(); x.restore();
    if(head){const q=P(head);const g=x.createRadialGradient(q[0],q[1],0,q[0],q[1],14*d);g.addColorStop(0,'#fff');g.addColorStop(.25,b.col);g.addColorStop(1,'rgba(0,0,0,0)');x.fillStyle=g;x.beginPath();x.arc(q[0],q[1],14*d,0,7);x.fill();}
  });
  // horizon
  const hg=x.createRadialGradient(cx,cy,2*sc*0.9,cx,cy,2*sc*1.6);hg.addColorStop(0,'rgba(255,170,90,.55)');hg.addColorStop(1,'rgba(0,0,0,0)');
  x.fillStyle=hg;x.beginPath();x.arc(cx,cy,2*sc*1.6,0,7);x.fill();
  x.fillStyle='#000';x.beginPath();x.arc(cx,cy,2*sc,0,7);x.fill();
  x.strokeStyle='rgba(255,190,120,.9)';x.lineWidth=1*d;x.beginPath();x.arc(cx,cy,2*sc,0,7);x.stroke();
  x.fillStyle='rgba(230,225,214,.75)';x.fillText('event horizon R_s',cx-2*sc-6*d-x.measureText('event horizon R_s').width,cy-2*sc-4*d);
  const D=derived(10**state.logM,10**state.logD);
  $('clock').textContent=`t = ${(t*speed*D.m/C).toFixed(1)} s of light-travel · 1 Rs = ${sci(D.Rs)} m`;
}
function simLoop(now){requestAnimationFrame(simLoop); if(sim.visible) drawSim(now);}
new IntersectionObserver(es=>sim.visible=es[0].isIntersecting).observe(sim.cv);

/* =========================================================
   UI + live values
   ========================================================= */
const inM=$('in-m'), inD=$('in-d'), inB=$('in-b');
function statusText(tr){
  if(tr.status==='captured') return ['cap','Captured — spirals through the horizon'];
  if(tr.status==='trapped') return ['orb','Trapped on the photon sphere (>6 orbits)'];
  if(tr.turns>0.75) return ['orb',`Whirls ${tr.turns.toFixed(2)} turns near the photon sphere, then escapes`];
  return ['esc',`Escapes — deflected ${tr.deflDeg.toFixed(2)}°`];
}
function update(rebuild=true){
  const Ms=10**state.logM, Dk=10**state.logD, D=derived(Ms,Dk);
  $('v-m').textContent=massStr(Ms); $('v-d').textContent=distStr(Dk); $('v-b').textContent=state.bRs.toFixed(3)+' Rs';
  $('lg-u').textContent=state.bRs.toFixed(2)+' Rs';
  if(rebuild){ sim.custom={key:'U',bRs:state.bRs,col:'#ffffff',tr:trace(state.bRs*2)}; const L=[0];const p=sim.custom.tr.pts;for(let i=1;i<p.length;i++)L.push(L[i-1]+Math.hypot(p[i][0]-p[i-1][0],p[i][1]-p[i-1][1]));sim.custom.len=L; }
  const tr=sim.custom.tr; const [cls,txt]=statusText(tr);
  $('st').className='status '+cls; $('st').textContent=txt;
  const weak=2/state.bRs*180/Math.PI;
  $('ro').innerHTML=[
    ['R_s',sci(D.Rs)+' m'],['R_s (AU)',fx(D.Rs/AU,4)],['Photon sphere',sci(D.rph)+' m'],['b_c',sci(D.bc)+' m'],['ISCO',sci(D.isco)+' m'],
    ['Shadow θ',fx(D.shadow,2)+' μas'],['Custom b',sci(state.bRs*D.Rs)+' m'],['r_min',fx(tr.rmin/2,3)+' Rs'],
    ['Exact α',tr.deflDeg===null?'—':fx(tr.deflDeg,2)+'°'],['Weak-field α',fx(weak,2)+'°'],['Swept angle',fx(tr.turns*360,1)+'°']
  ].map(([a,b])=>`<span>${a}</span><span>${b}</span>`).join('');
  // physics cards + hero + mission
  $('p-rs').textContent=sci(D.Rs)+' m'; $('p-ph').textContent=sci(D.rph)+' m'; $('p-bc').textContent=sci(D.bc)+' m'; $('p-sh').textContent=fx(D.shadow,1)+' μas';
  $('h-m').textContent=massStr(Ms); $('h-d').textContent=distStr(Dk); $('h-rs').textContent=sci(D.Rs)+' m'; $('h-sh').textContent=fx(D.shadow,1)+' μas';
  $('k-rs').innerHTML=sci(D.Rs)+'<small>m</small>'; $('k-ph').innerHTML=sci(D.rph)+'<small>m</small>'; $('k-bc').innerHTML=sci(D.bc)+'<small>m</small>'; $('k-sh').innerHTML=fx(D.shadow,1)+'<small>μas</small>';
  drawSky(D); renderTable2(D,tr); dilUpdate();
}
function setSliders(){inM.value=state.logM;inD.value=state.logD;inB.value=state.bRs;}
inM.oninput=()=>{state.logM=+inM.value;update(false);};
inD.oninput=()=>{state.logD=+inD.value;update(false);};
inB.oninput=()=>{state.bRs=+inB.value;update(true);};
document.querySelectorAll('[data-preset]').forEach(b=>b.onclick=()=>{
  const k=b.dataset.preset;
  if(k==='sgr'){state.logM=Math.log10(4.3e6);state.logD=Math.log10(8.28);}
  if(k==='m87'){state.logM=Math.log10(6.5e9);state.logD=Math.log10(16800);}
  if(k==='bc'){state.bRs=1.5*Math.sqrt(3)+0.0004;}
  if(k==='b3'){state.bRs=3.0;state.logM=Math.log10(4.3e6);state.logD=Math.log10(8.28);}
  setSliders(); update(true); sim.t0=performance.now();
  if(b.closest('#tests')) document.getElementById('tb2').scrollIntoView({behavior:'smooth',block:'center'});
});
$('t-replay').onclick=()=>sim.t0=performance.now();
$('t-fan').onclick=e=>{sim.showFan=!sim.showFan;e.currentTarget.classList.toggle('on',sim.showFan);if(sim.showFan&&!sim.fan.length)buildFan();};
$('t-disc').onclick=e=>{sim.showDisc=!sim.showDisc;e.currentTarget.classList.toggle('on',sim.showDisc);};
$('t-zoom').onclick=e=>{sim.zoom=(sim.zoom+1)%ZOOMS.length;e.currentTarget.innerHTML='Zoom: '+ZOOMS[sim.zoom]+' R<sub>s</sub>';};

/* sky view */
function drawSky(D){
  const c=$('skyc'),x=c.getContext('2d'),N=c.width;x.fillStyle='#000';x.fillRect(0,0,N,N);
  const span=130; const px=N/span; const cx=N/2,cy=N/2;
  const r=D.shadow/2*px; const rc=Math.min(r,N*0.47);
  // glow ring
  for(let i=0;i<40;i++){const rr=rc*(0.85+i*0.012);x.strokeStyle=`rgba(255,${150+i*2},${70+i},${0.06*(1-Math.abs(i-12)/28)})`;x.lineWidth=6;x.beginPath();x.arc(cx,cy,rr,0,7);x.stroke();}
  const g=x.createRadialGradient(cx-rc*.25,cy,rc*.6,cx,cy,rc*1.35);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(.55,'rgba(255,160,80,.55)');g.addColorStop(.7,'rgba(255,120,50,.25)');g.addColorStop(1,'rgba(0,0,0,0)');
  x.fillStyle=g;x.beginPath();x.arc(cx,cy,rc*1.35,0,7);x.fill();
  x.fillStyle='#000';x.beginPath();x.arc(cx,cy,rc*0.78,0,7);x.fill();
  // EHT band
  const re=51.8/2*px, rb=2.3/2*px;
  x.strokeStyle='rgba(143,195,223,.18)';x.lineWidth=rb*2;x.beginPath();x.arc(cx,cy,re,0,7);x.stroke();
  x.setLineDash([8,8]);x.strokeStyle='rgba(143,195,223,.95)';x.lineWidth=2;x.beginPath();x.arc(cx,cy,re,0,7);x.stroke();x.setLineDash([]);
  x.strokeStyle='rgba(255,207,143,.95)';x.lineWidth=2;x.beginPath();x.arc(cx,cy,rc,0,7);x.stroke();
  // scale bar
  x.fillStyle='#e6e1d6';x.fillRect(30,N-40,20*px,3);x.font='20px IBM Plex Mono';x.fillText('20 μas',30,N-52);
  x.fillStyle='rgba(143,195,223,.95)';x.fillText('EHT 51.8 μas',N-200,40);x.fillStyle='rgba(255,207,143,.95)';x.fillText('model '+D.shadow.toFixed(1)+' μas',N-200,68);
  if(r>N*0.47){x.fillStyle='#ff8a80';x.fillText('shadow off-scale',30,40);}
  $('sky-c').innerHTML=fx(D.shadow,1)+'<small>μas</small>';
  const err=(D.shadow-51.8)/51.8*100; $('sky-e').innerHTML=(err>=0?'+':'')+fx(err,1)+'<small>%</small>';
}

/* tests */
const pill=(ok)=>`<span class="pill ${ok?'pass':'fail'}">${ok?'PASS':'FAIL'}</span>`;
const pct=(a,b)=>{const v=(a-b)/b*100;return Math.abs(v)<0.05?0:v;};
let T1rows=[], T2rows=[];
function renderTable1(){
  const D=derived(4.3e6,8.28);
  const A=trace(4), B=trace(5.2), Cc=trace(20);
  const rows=[
    ['T1','R_s','1.27 × 10¹⁰ m',sci(D.Rs)+' m',pct(D.Rs,1.27e10),Math.abs(pct(D.Rs,1.27e10))<25],
    ['T2','Photon sphere','1.9 × 10¹⁰ m',sci(D.rph)+' m',pct(D.rph,1.9e10),Math.abs(pct(D.rph,1.9e10))<25],
    ['T3','b_c','3.3 × 10¹⁰ m',sci(D.bc)+' m',pct(D.bc,3.3e10),Math.abs(pct(D.bc,3.3e10))<25],
    ['T4','ISCO (3 R_s)','3.8 × 10¹⁰ m',sci(D.isco)+' m',pct(D.isco,3.8e10),Math.abs(pct(D.isco,3.8e10))<25],
    ['T5','Beam A · b = 2.0 R_s','Captured',`${A.status} · swept ${fx(A.turns*360,0)}°`,null,A.status==='captured'],
    ['T6','Beam B · b = 2.6 R_s','Near photon sphere',`${B.status} after ${fx(B.turns,2)} turns · r_min = ${fx(B.rmin/2,3)} R_s`,pct(B.rmin/2,1.5),Math.abs(pct(B.rmin/2,1.5))<25],
    ['T7','Beam C · b = 10 R_s','≈ 13–14° (weak 11.46°)',`${Cc.status} · α = ${fx(Cc.deflDeg,2)}°`,pct(Cc.deflDeg,13.5),Cc.status==='escaped'&&Math.abs(pct(Cc.deflDeg,13.5))<25],
    ['T8','Shadow diameter','51.8 ± 2.3 μas (EHT)',fx(D.shadow,2)+' μas',pct(D.shadow,51.8),Math.abs(pct(D.shadow,51.8))<25],
  ];
  T1rows=rows;
  $('tb1').innerHTML='<tr><th>#</th><th>Test</th><th>Expected</th><th>Computed</th><th>Δ</th><th>Result</th></tr>'+rows.map(r=>`<tr><td class="id">${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td><td>${r[4]===null?'—':(r[4]>=0?'+':'')+fx(r[4],1)+'%'}</td><td>${pill(r[5])}</td></tr>`).join('');
  $('l-c').textContent=fx(Cc.deflDeg,2); $('l-c2').textContent=fx(pct(Cc.deflDeg,11.459),0);
  $('l-b').textContent=fx(B.turns,2); $('l-b2').textContent=fx(B.rmin/2,3); $('l-s').textContent=fx(D.shadow,1);
}
function renderTable2(D,tr){
  const Ms=10**state.logM, Dk=10**state.logD;
  const isM87=Math.abs(Math.log10(Ms/6.5e9))<0.01 && Math.abs(Math.log10(Dk/16800))<0.01;
  const isSgr=Math.abs(Math.log10(Ms/4.3e6))<0.01 && Math.abs(Math.log10(Dk/8.28))<0.01;
  const refSh=isM87?42:(isSgr?51.8:null);
  const weak=2/state.bRs*180/Math.PI;
  const bcR=1.5*Math.sqrt(3);
  const expOutcome=state.bRs<bcR?'Captured (b < b_c)':'Escapes (b > b_c)';
  const outOK=(state.bRs<bcR)===(tr.status==='captured');
  const rows=[
    ['C1','Input',`M = ${massStr(Ms)}, D = ${distStr(Dk)}, b = ${state.bRs.toFixed(3)} R_s`,'—','',null],
    ['C2','R_s = 2GM/c²','scales ∝ M',sci(D.Rs)+' m · '+fx(D.Rs/AU,3)+' AU','',true],
    ['C3','Shadow 2b_c/D',refSh?refSh+' μas (EHT)':'no measurement',fx(D.shadow,2)+' μas',refSh?pct(D.shadow,refSh):null,refSh?Math.abs(pct(D.shadow,refSh))<25:true],
    ['C4','Custom beam outcome',expOutcome,statusText(tr)[1],'',outOK],
    ['C5','Custom beam deflection',`weak-field ${fx(weak,2)}°`,tr.deflDeg===null?'— (captured)':fx(tr.deflDeg,2)+'°',tr.deflDeg===null?null:pct(tr.deflDeg,weak),tr.deflDeg===null?outOK:tr.deflDeg>=weak*0.98],
  ];
  T2rows=rows;
  $('tb2').innerHTML='<tr><th>#</th><th>Test</th><th>Expected</th><th>Computed</th><th>Δ</th><th>Result</th></tr>'+rows.map(r=>`<tr><td class="id">${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td><td>${r[4]===null||r[4]===''?'—':(r[4]>=0?'+':'')+fx(r[4],1)+'%'}</td><td>${r[5]===null?'—':pill(r[5])}</td></tr>`).join('');
}
$('copy').onclick=async()=>{
  const fmt=(rows)=>rows.map(r=>`${r[0]}\t${r[1]}\t${r[2]}\t${r[3]}\t${r[4]===null||r[4]===''?'-':fx(r[4],1)+'%'}\t${r[5]===null?'-':(r[5]?'PASS':'FAIL')}`).join('\n');
  const txt='BENCHMARK (M=4.3e6 Msun, D=8.28 kpc)\n'+fmt(T1rows)+'\n\nCHANGED INPUT\n'+fmt(T2rows);
  try{await navigator.clipboard.writeText(txt);toast('Results copied');}catch(e){toast('Clipboard blocked by browser');}
};
function toast(m){const t=$('toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),1600);}

/* time dilation */
const dil=$('dil');
function dilUpdate(){
  const D=derived(10**state.logM,10**state.logD);
  const x=10**(+dil.value); // (r-Rs)/Rs
  const f=1/Math.sqrt(1-1/(1+x));
  const hm=x*D.Rs;
  $('dil-h').textContent=hm>1e9?sci(hm)+' m':(hm>1000?fx(hm/1000,1)+' km':fx(hm,2)+' m');
  const hrs=f; let out;
  if(hrs<48) out=fx(hrs,3)+'<small>hours on Earth</small>'; else if(hrs<24*365*2) out=fx(hrs/24,1)+'<small>days on Earth</small>'; else out=fx(hrs/8766,2)+'<small>years on Earth</small>';
  $('dil-out').innerHTML=out;
  const xm=1/(61362*61362);
  $('dil-note').innerHTML=`Factor ${f<1e4?fx(f,3):sci(f)} · "1 h = 7 yr" needs a hover ${fx(xm*D.Rs,1)} m above this horizon`;
}
dil.oninput=dilUpdate;

/* progress + reveal + nav */
const secs=['top','lit','idea','physics','simulate','tests','feasible'];
$('prog').innerHTML=secs.map(s=>`<a href="#${s}" data-s="${s}"></a>`).join('');
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){document.querySelectorAll('#prog a, .nav .links a').forEach(a=>a.classList.toggle('on',a.getAttribute('href')==='#'+e.target.id));}}),{rootMargin:'-45% 0px -50% 0px'});
secs.forEach(s=>io.observe($(s)));
const rv=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');rv.unobserve(e.target);}}),{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>rv.observe(el));

/* boot */
setSliders(); buildPaths(); simSize(); addEventListener('resize',simSize);
renderTable1(); update(true); requestAnimationFrame(simLoop);
