/* SGR A* — physics core. Runs in the browser and in Node (npm test). */

/* =========================================================
   PHYSICS CORE (SI + geometric units)
   ========================================================= */
const G=6.6743e-11, C=299792458, MSUN=1.98847e30, KPC=3.0856775814913673e19, UAS=4.84813681109536e-12, AU=1.495978707e11;
const state={logM:Math.log10(4.3e6), logD:Math.log10(8.28), bRs:4.0};

function derived(Msun,Dkpc){
  const M=Msun*MSUN, m=G*M/(C*C);
  return {M, m, Rs:2*m, rph:3*m, bc:3*Math.sqrt(3)*m, isco:6*m, D:Dkpc*KPC,
          shadow: 2*3*Math.sqrt(3)*m/(Dkpc*KPC)/UAS};
}
/* Integrate d²u/dφ² + u = 3u² (M = 1). b in units of M. Returns path in units of M. */
function trace(b, opts={}){
  const r0=opts.r0||1e4, h=opts.h||0.002, keepR=opts.keepR||140;
  let u=1/r0; const u0=u;
  let du=Math.sqrt(Math.max(0,1/(b*b)-u*u+2*u*u*u));
  const phi0=Math.PI-Math.asin(b*u0);
  let s=0, rmin=r0, status='escaped';
  const pts=[]; let k=0;
  const f=(u,d)=>[d,3*u*u-u];
  while(true){
    const k1=f(u,du), k2=f(u+h/2*k1[0],du+h/2*k1[1]), k3=f(u+h/2*k2[0],du+h/2*k2[1]), k4=f(u+h*k3[0],du+h*k3[1]);
    u+=h/6*(k1[0]+2*k2[0]+2*k3[0]+k4[0]); du+=h/6*(k1[1]+2*k2[1]+2*k3[1]+k4[1]); s+=h;
    const r=1/u; if(u>0&&r<rmin) rmin=r;
    const phi=phi0-s;
    if(r<keepR && (k++%3===0)) pts.push([Math.cos(phi)*r, Math.sin(phi)*r]);
    if(u>=0.5){ status='captured'; pts.push([Math.cos(phi)*2,Math.sin(phi)*2]); break; }
    if(du<0 && u<=u0){ status='escaped'; s-=(u0-u)/(-du); break; }
    if(s>12*Math.PI){ status='trapped'; break; }
  }
  const defl = status==='escaped' ? s-(Math.PI-2*Math.asin(b*u0)) : null;
  // prepend straight entry segment from far left
  if(pts.length){ const p=pts[0]; pts.unshift([p[0]-400,b]); }
  return {b, status, pts, deflRad:defl, deflDeg:defl===null?null:defl*180/Math.PI, rmin, turns:s/(2*Math.PI)};
}

/* ---------- formatting ---------- */
const SUP={'-':'⁻','0':'⁰','1':'¹','2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹'};
function sci(x,d=3){ if(!isFinite(x))return '—'; const e=Math.floor(Math.log10(Math.abs(x))); const m=x/Math.pow(10,e); return m.toFixed(d-1)+' × 10'+String(e).split('').map(c=>SUP[c]).join(''); }
const fx=(x,d=2)=>Number(x).toFixed(d);
function massStr(Msun){return sci(Msun,3)+' M☉';}
function distStr(kpc){return kpc>=1000? fx(kpc/1000,1)+' Mpc' : fx(kpc,2)+' kpc';}
const $=id=>document.getElementById(id);


if (typeof module !== 'undefined' && module.exports) {
  module.exports = { G, C, MSUN, KPC, UAS, AU, derived, trace, sci };
}
